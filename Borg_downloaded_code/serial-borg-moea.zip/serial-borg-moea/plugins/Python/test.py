from sys import *
from math import *
from plugins.Python.borg import Borg

nvars = 11
nobjs = 2
k = nvars - nobjs + 1

def DTLZ2(*vars):
	g = 0

	for i in range(nvars-k, nvars):
		g = g + (vars[i] - 0.5)**2

	objs = [1.0 + g]*nobjs

	for i in range(nobjs):
		for j in range(nobjs-i-1):
			objs[i] = objs[i] * cos(0.5 * pi * vars[j])
		if i != 0:
			objs[i] = objs[i] * sin(0.5 * pi * vars[nobjs-i-1])

	return objs

borg = Borg(nvars, nobjs, 0, DTLZ2)
borg.setBounds(*[[0, 1]]*nvars)
borg.setEpsilons(*[0.01]*nobjs)

result = borg.solve({"maxEvaluations":100000})

for solution in result:
	print(solution.getObjectives())


# '''This is the objective function that is activated by the Borg
# It accepts a vector (x) that contains the decision variables and returns the objective values'''
#
#
# def objective_func(*x):
# 	objs = np.zeros((2,))
# 	constrs = np.zeros((2,))
#
# 	# OBJECTIVE - 1
# 	# round the decision variables to 0 - no sensor and 1 - sensor is placed
# 	x = np.round(x)
# 	# objective 1 - minimize number of active sensors
# 	objs[0] = np.sum(x)
#
# 	# CONSTRAINTS
# 	# constrain of minimum two sensors (more realistic) and maximum? 50/100/300
# 	cons1 = 2
# 	cons2 = 300
# 	if objs[0] < cons1:
# 		constrs[0] = 1
# 	if objs[0] > cons2:
# 		constrs[1] = 1
#
# 	# OBJECTIVE - 2
# 	# sum the sensors to calculate the final PED
# 	total_summed_PED = np.sqrt(np.sum(total_PED.iloc[:, x == 1], axis=1))
#
# 	# maximize min PEDs, given locations of active sensors.
# 	[c, idx] = np.unique(total_variations[:, 0:2], axis=0, return_inverse=True)
# 	min_PED = total_summed_PED.groupby(idx).min()
# 	mean_PED = np.mean(min_PED)
#
# 	objs[1] = -mean_PED
#
# 	# # write to a file
# 	# if np.mod(cnt, 11) == 0:
# 	# 	total_objs.append(objs)
# 	# 	total_x.append(x)
#     #
# 	# cnt = cnt + 1
#
# 	return objs, constrs
#
#
# import numpy as np
# import scipy.io as sio
# import datetime
# import tqdm
# import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
# import matplotlib.pyplot as plt
# from sklearn.model_selection import train_test_split
# from sklearn import preprocessing
# import seaborn as sns; sns.set(style="ticks", color_codes=True)
#
# global total_PED
# global total_variations
# global cnt
# global total_objs
# global total_x
#
# mat = sio.loadmat('/Users/iditbela/Documents/Shai_Kendler/Borg-1.9/Results/total_PED_sensors_winds_SC_mult_RP.mat')
# total_PED = mat['total_PED_sensors_winds_mult']
# # change total_PED to a dataframe
# total_PED = pd.DataFrame(data = total_PED)
#
# mat = sio.loadmat('/Users/iditbela/Documents/Shai_Kendler/Borg-1.9/Results/total_ind_RP.mat')
# total_variations = mat['total_ind']
#
# cnt = 0
#
# total_objs = []
# total_x = []
#
# # which indeces are NaNs?
# nan_idx = np.where(total_PED.iloc[0].isnull())
# NumOfSens_reduced = np.shape(total_PED)[1] - np.shape(nan_idx)[1]
# total_PED.drop(total_PED.columns[nan_idx], axis=1, inplace=True)
#
#
# # run borg
# NumOfVars = NumOfSens_reduced  # Number of sensors
# NumOfObj = 2 # Number of Objectives
# NumOfCons = 2
# NFE=10e5 # the number of objective function evaluations, defines how many times
# #the Borg MOEA can invoke objectiveFcn.  Once the NFE limit is reached, the
# #algorithm terminates and returns the result.
#
# borg = Borg(NumOfVars, NumOfObj, NumOfCons, objective_func)
# borg.setBounds(*[[0, 1]]*NumOfVars)
# borg.setEpsilons(1, 0.5e-3)
#
# result = borg.solve({"maxEvaluations":NFE})